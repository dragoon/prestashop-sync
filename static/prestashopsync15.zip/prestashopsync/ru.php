<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{prestashopsync}prestashop>prestashopsync_34aaec1bfbba2a8db03769a89c3ff744'] = 'Необходимо настроить модуль Prestashop Sync';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_087505acc11e9e58ce5a51ec8d2749d4'] = 'Модуль интеграции с prestashop-sync.com';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Удалить все данные?';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_375df1fda0b20b05a7bee769524a3181'] = 'Необходимо ввести пароль.';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_9d9611399af7725caea6befd70d09777'] = 'Интеграция установлена. Пожалуйста перегенерируйте файл .htaccess на вкладке ';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_d6f54d40acd93340fa9b83d732aad2ff'] = 'Интеграция не удалась. Попробуйте переустановить модуль.';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_b2639a3cb63f48fde6cc0d4410dceed4'] = 'Интеграция с Prestashop Sync активна. Можно войти в интерфейс сервиса:';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_f4f70727dc34561dfde1a3c529b6205c'] = 'Настройки';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_06608a95bbb7e5f0837c16027cc129ad'] = 'Email для входа в сервис';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_8630f1f46830dfccef2f1e8355986465'] = 'Пароль для входа в сервис';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_8451402803648588e28f4dfc364cb8ec'] = 'Установить интеграцию с Prestashop Sync';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_2a4968416e259e54bfc02c12fae799bc'] = 'Регистрируясь на сервисе Prestashop-Sync, вы соглашаетесь с нашими';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_8055de218609b377400cff96e3f4e8f6'] = 'Условиями использования';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_8cf5a8a3bcdf9ef1b49a3297e31228d7'] = 'Политикой конфиденциальности';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_6a26f548831e6a8c26bfbbd9f6ec61e0'] = 'Помощь';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_e169a177640d7917f5b39f482fa5ac2e'] = 'Настройка интеграции Prestashop Sync';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_ed7ca80d6a7815737deba06d71433a8f'] = 'Для того чтобы настроить интеграцию, заполните поля email и пароль в форме наверху и нажмите кнопку \"Установить интеграцию\"';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_592678efe2361bc8fb0fddcd41a2e84f'] = 'После этого вы можете войти в интерфейс сервиса по адресу: ';
$_MODULE['<{prestashopsync}prestashop>prestashopsync_0240b054d0ecf05553aa3d8635d65cdd'] = 'По причинам безопасности, вы не можете поменять пароль к сервису после выполнения интеграции. Если вы забыли пароль, используйте форму восстановления пароля в интерфейсе сервиса.';
