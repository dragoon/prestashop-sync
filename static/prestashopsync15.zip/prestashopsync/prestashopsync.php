<?php

class PrestashopSync extends Module
{
    function __construct()
    {
        $this->name = 'prestashopsync';
        $this->tab = 'administration';
        $this->version = '1.0';
        $this->author = 'Prestashop Sync';
        $this->displayName = 'PrestaShop Sync';

        $this->custom_attributes = array('PRESTASHOP_SYNC_KEY', 'PRESTASHOP_SYNC_CONFIGURED');

        parent::__construct();

        if ($this->id AND !Configuration::get('PRESTASHOP_SYNC_CONFIGURED'))
            $this->warning = $this->l('Prestashop Sync needs to be configured');
        $this->description = $this->l('Prestashop-sync.com integration module');
        $this->confirmUninstall = $this->l('Are you sure you want to delete your details?');
    }

    function install()
    {
        if (!parent::install())
            return false;
        return true;
    }

    function uninstall()
    {
        foreach($this->custom_attributes as $attr) {
            if(!Configuration::deleteByName($attr))
                return false;
        }
        if (!parent::uninstall())
            return false;
        return true;
    }

    public function getContent()
    {
        $output = '<h2>'.$this->displayName.'</h2>';
        if (Tools::isSubmit('submit'.$this->name)) {
            // Create API KEY if necessary
            $key = Configuration::get('PRESTASHOP_SYNC_KEY');
            if (!$key) {
                $key = create_api_key();
            }
            Configuration::updateValue('PRESTASHOP_SYNC_KEY', $key);
            $domain = Tools::getShopDomain(false).__PS_BASE_URI__;
            if (!Tools::getValue('prestashop_sync_password')){
                $output .= '
                <div class="conf error">
                    <img src="../img/admin/error.png" alt="" title="" />
                    ' . $this->l('Password field is required.') . '
                </div>';
                return $output . $this->displayForm();
            }
            try {
                try {
                    register_key($key, $domain, Tools::getValue('prestashop_sync_email'), Tools::getValue('prestashop_sync_password'));
                    Configuration::updateValue('PRESTASHOP_SYNC_CONFIGURED', 1);
                }
                catch(ForbiddenException $e){
                    $output .= '
                    <div class="conf error">
                        <img src="../img/admin/error.png" alt="" title="" />
                        ' . $this->l('Your IP address is not the address of the shop domain.') . '
                    </div>';
                }
            }
            catch (Exception $e) {
                $output .= '
                <div class="conf error">
                    <img src="../img/admin/error.png" alt="" title="" />
                    ' . $this->l('Prestashop-Sync integration failed. Try reinstalling the module.') . '
                </div>';
            }
        }
        return $output . $this->displayForm();
    }

    public function displayForm()
    {
        $configured = Configuration::get('PRESTASHOP_SYNC_CONFIGURED');
        $output = "<script type='text/javascript'>
        $(document).ready(function() {
            $('#toggle_password').click(function() {
                var hidden = $(this).siblings('input:hidden');
                var visible = $(this).siblings('input:visible');
                visible.toggle();
                hidden.val(visible.val()).toggle().attr('name', visible.attr('name'));
                visible.removeAttr('name');
                return false;
            });
        });</script>";
        if ($configured) {
            $output .= '
            <div class="conf confirm">
                <img src="../img/admin/ok.gif" alt="" title="" />
                ' . $this->l('Prestashop Sync integration active. Access the service at ') . '
                    <a style="color:#0101EE; text-decoration:underline;" href="http://prestashop-sync.com/login">prestashop-sync.com/login</a>
            </div>';
        }
        $output .= '
        <form action="' . $_SERVER['REQUEST_URI'] . '" method="post">
            <fieldset class="width3">
                <legend>' . $this->l('Settings') . '</legend>
                <label>' . $this->l('Email to access prestashop-sync.com') . '</label>
                <div class="margin-form">
                    <input type="text" name="prestashop_sync_email" value="' . Tools::getValue('prestashop_sync_email', Configuration::get('PS_SHOP_EMAIL')) . '" />
                    </p>
                </div>
                <label>' . $this->l('Prestashop Sync Password') . ':</label>
                <div class="margin-form">
                    <input type="password" name="prestashop_sync_password" value="'.Tools::getValue('prestashop_sync_password').'" />
                    <input type="text" value="" style="display:none;"/>
                    <a id="toggle_password" title="toggle password" href="#" style="background: url(../modules/'.$this->name.'/star.png) no-repeat; width:16px; height:16px;display: inline-block;vertical-align: middle;"></a>
                </div>
                <center><input type="submit"';

        if ($configured) {
            $output .= ' disabled="disabled" ';
        }

        $output .= ' name="submit'.$this->name.'" value="' . $this->l('Install prestashop-sync integration') . '" class="button" /></center>';

	$output .= '<br><div class="warn">'. $this->l('By clicking on the button above, you agree with our') .
        ' <a href="http://prestashop-sync.com/en/terms/">' . $this->l('Terms&nbsp;of&nbsp;service') . '</a> & <a href="http://prestashop-sync.com/en/privacy/"">' . $this->l('Privacy&nbsp;policy'). '</a></div>
            </fieldset>
        </form>';

        $output .= '
        <fieldset class="space">
            <legend><img src="../img/admin/unknown.gif" alt="" class="middle" />' . $this->l('Help') . '</legend>
             <h3>' . $this->l('PrestaShop Sync integration configuration') . '</h3>
             <p>' . $this->l('To establish prestashop-sync integration, fill in the email and password fields above and press the <b>Install</b> button.'). '
             ' . $this->l('Then log in using specified credentials at '). '<a style="color:#0101EE; text-decoration:underline;" href="http://prestashop-sync.com/login">http://prestashop-sync.com/login</a>.</p>
             <p>' . $this->l('For security reasons, you cannot change the password after initial integration. If you forget the password, just use password restore form from the service website.'). '</p>
        </fieldset>';

        return $output;
    }

}

function str_rand($length = 32, $seeds = 'alphanum')
{
    // Possible seeds
    $seedings['alpha'] = 'abcdefghijklmnopqrstuvwqyz';
    $seedings['numeric'] = '0123456789';
    $seedings['alphanum'] = 'abcdefghijklmnopqrstuvwqyz0123456789';
    $seedings['hexidec'] = '0123456789abcdef';

    // Choose seed
    if (isset($seedings[$seeds]))
    {
        $seeds = $seedings[$seeds];
    }

    // Seed generator
    list($usec, $sec) = explode(' ', microtime());
    $seed = (float) $sec + ((float) $usec * 100000);
    mt_srand($seed);

    // Generate
    $str = '';
    $seeds_count = strlen($seeds);

    for ($i = 0; $length > $i; $i++)
    {
        $str .= $seeds{mt_rand(0, $seeds_count - 1)};
    }

    return $str;
}

function create_api_key() {
    Configuration::updateValue('PS_WEBSERVICE', 1);
    $webservice_key = new WebserviceKey();
    $webservice_key->key = strtoupper(str_rand());
    $resources = array("categories" => array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on"));
    $resources["combinations"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["configurations"] = array("GET" => "on", "POST" => "on", "HEAD" => "on");
    $resources["images"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["languages"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["products"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["product_feature_values"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["product_features"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["product_option_values"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["product_options"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["stock_availables"] = array("GET" => "on", "PUT" => "on", "HEAD" => "on");
    $resources["stock_movement_reasons"] = array("DELETE" => "on", "GET" => "on", "PUT" => "on", "POST" => "on", "HEAD" => "on");
    $resources["stock_movements"] = array("GET" => "on","HEAD" => "on");
    $resources["stocks"] = array("GET" => "on","HEAD" => "on");
    $webservice_key->add();
    WebserviceKey::setPermissionForAccount($webservice_key->id, $resources);
    Tools::generateHtaccess();
    return $webservice_key->key;
}

function register_key($key, $domain, $email, $password) {
    do_post_request('http://prestashop-sync.com/module_activate/', array("key" => $key, "domain" => $domain, "email" => $email, "password" => $password));
}

function do_post_request($url, $data, $optional_headers = null)
{
    $params = array('http' => array(
        'method' => 'POST',
        'content' => http_build_query($data)
    ));
    if ($optional_headers !== null) {
        $params['http']['header'] = $optional_headers;
    }
    $ctx = stream_context_create($params);
    $fp = @fopen($url, 'rb', false, $ctx);
    if (!$fp) {
        $pos = strpos($php_errormsg, '403');
        if ($pos!==false){
            throw new ForbiddenException();
        }
        throw new Exception("Problem with $url, $php_errormsg");
    }
    $response = @stream_get_contents($fp);
    if ($response === false) {
        throw new Exception("Problem reading data from $url, $php_errormsg");
    }
    return $response;
}

class ForbiddenException extends Exception {

}

?>